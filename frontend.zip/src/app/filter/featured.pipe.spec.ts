import { FeaturedPipe } from './featured.pipe';

describe('FeaturedPipe', () => {
  it('create an instance', () => {
    const pipe = new FeaturedPipe();
    expect(pipe).toBeTruthy();
  });
});
