import { SortbydatePipe } from './sortbydate.pipe';

describe('SortbydatePipe', () => {
  it('create an instance', () => {
    const pipe = new SortbydatePipe();
    expect(pipe).toBeTruthy();
  });
});
