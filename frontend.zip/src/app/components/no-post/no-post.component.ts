import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-no-post',
  templateUrl: './no-post.component.html',
  styleUrls: ['./no-post.component.css']
})
export class NoPostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
